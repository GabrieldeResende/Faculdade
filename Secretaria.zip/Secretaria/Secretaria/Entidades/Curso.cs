﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Secretaria.Entidades
{
    public class Curso
    {
        public string NomeCurso { get; set; }
        public string CodigoCurso { get; set; }
    }
}
